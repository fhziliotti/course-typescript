"use strict";
const a = 'Teste TS!';
console.log(a);
//# sourceMappingURL=basico.js.map