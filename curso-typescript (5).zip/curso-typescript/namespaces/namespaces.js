"use strict";
///<reference path="geometriaCirc.ts"/>
///<reference path="geometriaRect.ts"/>
// const PI = 2.99
console.log(Geometria.Area.circunferencia(10));
console.log(Geometria.Area.retangulo(12, 20));
// console.log(PI)
//# sourceMappingURL=namespaces.js.map