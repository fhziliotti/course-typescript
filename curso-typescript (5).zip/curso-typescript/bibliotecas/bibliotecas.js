"use strict";
// declare const $: any
$('body').append('Usando jQuery');
// $('body').append(true)
// $('body').
//# sourceMappingURL=bibliotecas.js.map