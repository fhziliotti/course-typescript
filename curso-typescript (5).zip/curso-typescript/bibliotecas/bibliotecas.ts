// declare const $: any

$('body').append('Usando jQuery')
// $('body').append(true)
// $('body').